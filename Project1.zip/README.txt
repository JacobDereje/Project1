Po Cheng Cheng(Brandon Cheng), chen7381
Jacob Dereje, derej006

Contributions:
Jacob - most shape class methods and constructor/ some FractalDrawer
Brandon - some shape class methods/ most FractalDrawer

How to run & compile:
    You will only need to compile the Fractal Drawer class(put Canvas and shape classes in same directory),
    and then you can run the program.

The userInput in the FractalDrawer's main method is assumed to be "circle", "rectangle" or "triangle".
Anything else the program would not work.

I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”
Po Cheng Cheng(Brandon Cheng)

I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”
Jacob Dereje